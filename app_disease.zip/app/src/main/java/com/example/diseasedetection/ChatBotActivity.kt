package com.example.diseasedetection

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class ChatBotActivity : AppCompatActivity() {

    private lateinit var chatLayout: LinearLayout
    private lateinit var userInput: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var scrollView: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_bot)

        chatLayout = findViewById(R.id.chatLayout)
        userInput = findViewById(R.id.userInput)
        sendButton = findViewById(R.id.sendButton)
        scrollView = findViewById(R.id.chatScrollView)

        sendButton.setOnClickListener {
            val msg = userInput.text.toString().trim()
            if (msg.isNotEmpty()) {
                addMessage("You", msg)
                userInput.setText("")
                sendMessageToBot(msg)
            }
        }
    }

    private fun addMessage(sender: String, message: String) {
        val textView = TextView(this).apply {
            text = "$sender: $message"
            textSize = 16f
            setPadding(20, 14, 20, 14)
            setTextColor(if (sender == "You") 0xFF0D47A1.toInt() else 0xFF222222.toInt())
            setBackgroundResource(if (sender == "You") R.drawable.bubble_user else R.drawable.bubble_bot)
        }

        chatLayout.addView(textView)

        // Scroll to bottom after adding message
        scrollView.post {
            scrollView.fullScroll(ScrollView.FOCUS_DOWN)
        }
    }

    private fun sendMessageToBot(message: String) {
        val client = OkHttpClient()
        val json = JSONObject().put("message", message)
        val requestBody = json.toString()
            .toRequestBody("application/json".toMediaTypeOrNull())

        val request = Request.Builder()
            .url("http://10.4.73.18:5050/chat") // ✅ Replace with your chatbot Flask server IP
            .post(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    addMessage("Bot", "⚠️ Failed to connect: ${e.message}")
                }
            }

            override fun onResponse(call: Call, response: Response) {
                try {
                    val bodyStr = response.body?.string()
                    if (bodyStr.isNullOrEmpty()) {
                        runOnUiThread {
                            addMessage("Bot", "⚠️ Empty response from server.")
                        }
                        return
                    }

                    val jsonResponse = JSONObject(bodyStr)
                    val reply = jsonResponse.optString("reply", "⚠️ No reply found.")
                    runOnUiThread {
                        addMessage("Bot", reply)
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        addMessage("Bot", "⚠️ Error parsing response.")
                    }
                }
            }
        })
    }
}
