package com.example.diseasedetection

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import ai.onnxruntime.*
import java.io.InputStream
import java.nio.FloatBuffer

class PneumoniaActivity : AppCompatActivity() {

    private lateinit var imageView: ImageView
    private lateinit var resultText: TextView
    private lateinit var btnSelect: Button
    private lateinit var btnPredict: Button

    private var selectedBitmap: Bitmap? = null
    private lateinit var ortEnv: OrtEnvironment
    private lateinit var ortSession: OrtSession

    private val classLabels = listOf("Normal", "Pneumonia")

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            res.data?.data?.let { uri ->
                val bmp = uriToBitmap(uri)
                selectedBitmap = bmp
                imageView.setImageBitmap(bmp)
                resultText.text = "Image loaded. Ready for prediction."
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pneumonia)

        // Load ONNX model
        ortEnv = OrtEnvironment.getEnvironment()
        ortSession = ortEnv.createSession(assets.open("pneumonia_resnet50.onnx").readBytes())

        // UI setup
        imageView  = findViewById(R.id.imgPreview)
        resultText = findViewById(R.id.txtPredictionResult)
        btnSelect  = findViewById(R.id.btnSelectImage)
        btnPredict = findViewById(R.id.btnPredictImage)

        btnSelect.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            imagePicker.launch(intent)
        }

        btnPredict.setOnClickListener {
            selectedBitmap?.let {
                val input = preprocessImage(it)
                val (label, confidence) = runOnnxPrediction(input)
                resultText.text = "Prediction: $label\nConfidence: $confidence%"
            } ?: run {
                resultText.text = "Please select an image first."
            }
        }
    }

    private fun uriToBitmap(uri: Uri): Bitmap {
        val inputStream: InputStream? = contentResolver.openInputStream(uri)
        return BitmapFactory.decodeStream(inputStream!!)
    }

    private fun preprocessImage(bitmap: Bitmap): FloatArray {
        val resized = Bitmap.createScaledBitmap(bitmap, 224, 224, true)
        val floatValues = FloatArray(3 * 224 * 224)
        var index = 0

        for (y in 0 until 224) {
            for (x in 0 until 224) {
                val pixel = resized.getPixel(x, y)

                // Extract RGB and normalize using ImageNet stats
                val r = (((pixel shr 16) and 0xFF) / 255.0f - 0.485f) / 0.229f
                val g = (((pixel shr 8) and 0xFF) / 255.0f - 0.456f) / 0.224f
                val b = ((pixel and 0xFF) / 255.0f - 0.406f) / 0.225f

                floatValues[index] = r; index++
                floatValues[index] = g; index++
                floatValues[index] = b; index++
            }
        }

        return floatValues
    }

    private fun runOnnxPrediction(inputData: FloatArray): Pair<String, Int> {
        val tensor = OnnxTensor.createTensor(
            ortEnv,
            FloatBuffer.wrap(inputData),
            longArrayOf(1, 3, 224, 224)
        )

        val result = ortSession.run(mapOf(ortSession.inputNames.iterator().next() to tensor))
        val output = result[0].value

        val scores: FloatArray = when (output) {
            is FloatArray -> output
            is Array<*>   -> output[0] as FloatArray
            else -> floatArrayOf(0f, 0f)
        }

        val maxIdx = scores.toList().indexOf(scores.maxOrNull()!!)
        val confidence = softmax(scores)[maxIdx]
        return Pair(classLabels[maxIdx], (confidence * 100).toInt())
    }

    private fun softmax(logits: FloatArray): FloatArray {
        val expScores = logits.map { Math.exp(it.toDouble()) }
        val sumExp = expScores.sum()
        return expScores.map { (it / sumExp).toFloat() }.toFloatArray()
    }
}
