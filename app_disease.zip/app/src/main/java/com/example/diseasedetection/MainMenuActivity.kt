package com.example.diseasedetection

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class MainMenuActivity : AppCompatActivity() {

    private lateinit var welcomeText: TextView
    private lateinit var cardParkinson: CardView
    private lateinit var cardDiabetes: CardView
    private lateinit var cardPneumonia: CardView
    private lateinit var btnCombinedTest: Button
    private lateinit var cardChatBot: CardView  // ✅ NEW

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)

        // Find Views
        welcomeText = findViewById(R.id.welcomeText)
        cardParkinson = findViewById(R.id.cardParkinson)
        cardDiabetes = findViewById(R.id.cardDiabetes)
        cardPneumonia = findViewById(R.id.cardPneumonia)
        btnCombinedTest = findViewById(R.id.btnCombinedTest)
        cardChatBot = findViewById(R.id.cardChatBot)  // ✅ NEW

        // Dynamic welcome (optional: pull name from Firebase later)
        welcomeText.text = "Welcome, User!"

        // Click listeners
        cardParkinson.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        cardDiabetes.setOnClickListener {
            startActivity(Intent(this, DiabetesActivity::class.java))
        }

        cardPneumonia.setOnClickListener {
            startActivity(Intent(this, PneumoniaActivity::class.java))
        }

        btnCombinedTest.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java)) // Placeholder for now
        }

        // ✅ ChatBot Card Click
        cardChatBot.setOnClickListener {
            startActivity(Intent(this, ChatBotActivity::class.java))
        }
    }
}
