package com.example.diseasedetection

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import ai.onnxruntime.*
import java.io.*
import java.nio.FloatBuffer
import java.nio.charset.StandardCharsets

class DiabetesActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout
    private lateinit var txtResult: TextView
    private lateinit var ortEnv: OrtEnvironment
    private lateinit var ortSession: OrtSession

    private val featureLabels = listOf(
        "Pregnancies", "Glucose", "BloodPressure", "SkinThickness", "Insulin",
        "BMI", "DiabetesPedigreeFunction", "Age"
    )

    private val inputFields = mutableListOf<EditText>()

    private val pickCsv = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            res.data?.data?.let { uri ->
                val feat = parseCsv(uri)
                if (feat == null) {
                    txtResult.text = "CSV format incorrect."
                    return@registerForActivityResult
                }
                val pred = runOnnxPrediction(feat)
                txtResult.text = if (pred == 1) "Diabetes Detected" else "Healthy"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Load ONNX model
        ortEnv = OrtEnvironment.getEnvironment()
        ortSession = ortEnv.createSession(assets.open("svm_diabetes_model.onnx").readBytes())

        // Root layout
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(32, 32, 32, 32)
        }
        setContentView(ScrollView(this).apply { addView(container) })

        // Title
        container.addView(TextView(this).apply {
            text = "🩸 Diabetes Test"
            textSize = 20f
            setPadding(0, 0, 0, 24)
        })

        // File picker button
        container.addView(Button(this).apply {
            text = "Upload CSV File"
            setOnClickListener {
                val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "text/*" }
                pickCsv.launch(i)
            }
        })

        // Separator
        container.addView(TextView(this).apply {
            text = "\nOR\n"
            textSize = 16f
            setPadding(0, 24, 0, 16)
        })

        // Manual input form
        featureLabels.forEach { label ->
            container.addView(TextView(this).apply { text = label })
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or
                        InputType.TYPE_NUMBER_FLAG_DECIMAL or
                        InputType.TYPE_NUMBER_FLAG_SIGNED
                hint = "Enter $label"
            }
            inputFields += input
            container.addView(input)
        }

        // Predict button
        val predictBtn = Button(this).apply {
            text = "Predict Manually"
            setBackgroundColor(0xFF388E3C.toInt())
            setTextColor(0xFFFFFFFF.toInt())
        }
        container.addView(predictBtn)

        // Result TextView
        txtResult = TextView(this).apply {
            text = "Prediction result will appear here"
            textSize = 16f
            setPadding(0, 24, 0, 0)
        }
        container.addView(txtResult)

        predictBtn.setOnClickListener {
            try {
                val features = FloatArray(featureLabels.size) { i ->
                    inputFields[i].text.toString().trim().toFloat()
                }
                val pred = runOnnxPrediction(features)
                txtResult.text = if (pred == 1) "Diabetes Detected" else "Healthy"
            } catch (e: Exception) {
                txtResult.text = "Invalid input — please enter all values."
                Log.e("DiabetesManual", "Input parse error", e)
            }
        }
    }

    private fun parseCsv(uri: Uri): FloatArray? {
        return try {
            contentResolver.openInputStream(uri)?.bufferedReader(StandardCharsets.UTF_8).use { reader ->
                val dataLine = reader?.lineSequence()
                    ?.firstOrNull { it.trim().isNotEmpty() && !it.contains("Pregnancies") } ?: return null
                val parts = dataLine.split(',', '\t').map { it.trim() }.filter { it.isNotEmpty() }
                if (parts.size != featureLabels.size) null else FloatArray(parts.size) { i -> parts[i].toFloat() }
            }
        } catch (e: Exception) {
            Log.e("CSV", "Parse error", e); null
        }
    }

    private fun runOnnxPrediction(feat: FloatArray): Int {
        val tensor = OnnxTensor.createTensor(
            ortEnv,
            FloatBuffer.wrap(feat),
            longArrayOf(1, feat.size.toLong())
        )
        ortSession.run(mapOf(ortSession.inputNames.iterator().next() to tensor)).use { res ->
            val v = res[0].value

            return when (v) {
                is LongArray -> v[0].toInt()
                is IntArray  -> v[0]
                is FloatArray -> if (v[0] >= 0f) 1 else 0
                is DoubleArray -> if (v[0] >= 0.0) 1 else 0
                else -> 0
            }
        }
    }
}
