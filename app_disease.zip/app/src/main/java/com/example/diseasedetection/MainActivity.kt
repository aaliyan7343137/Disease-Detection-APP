package com.example.diseasedetection

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.*
import java.nio.FloatBuffer
import java.nio.charset.StandardCharsets

class MainActivity : AppCompatActivity() {

    // UI
    private lateinit var btnSelectAudio:  Button
    private lateinit var btnPredict:      Button
    private lateinit var btnSelectCsv:    Button
    private lateinit var btnManualInput:  Button
    private lateinit var txtSelectedFile: TextView
    private lateinit var txtResult:       TextView

    // Runtime
    private var   selectedFileUri: Uri?   = null
    private var   selectedFile:    File?  = null
    private lateinit var ortEnv:          OrtEnvironment
    private lateinit var ortSession:      OrtSession

    /* ------------  Activity-result launchers  ------------ */

    private val pickAudio = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            res.data?.data?.let { uri ->
                selectedFileUri = uri
                selectedFile    = uriToTempFile(uri)
                txtSelectedFile.text = getFileName(uri)
            }
        }
    }

    private val pickCsv = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            res.data?.data?.let { uri ->
                val feat = parseCsv(uri)
                if (feat == null) {
                    txtResult.text = "CSV format incorrect."
                    return@registerForActivityResult
                }
                val pred = runOnnxPrediction(feat)
                txtResult.text = if (pred == 1) "Parkinson's Detected" else "Healthy"
            }
        }
    }

    /* --------------------  onCreate  -------------------- */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // ---- findViewById ----
        btnSelectAudio  = findViewById(R.id.btnSelectAudio)
        btnPredict      = findViewById(R.id.btnPredict)
        btnSelectCsv    = findViewById(R.id.btnSelectCsv)
        btnManualInput  = findViewById(R.id.btnManualInput)
        txtSelectedFile = findViewById(R.id.txtSelectedFile)
        txtResult       = findViewById(R.id.txtResult)

        // ---- load ONNX once ----
        ortEnv     = OrtEnvironment.getEnvironment()
        ortSession = ortEnv.createSession(assets.open("svm_parkinsons_model.onnx").readBytes())

        /* ---------- listeners ---------- */

        btnSelectAudio.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "audio/*" }
            pickAudio.launch(i)
        }

        btnPredict.setOnClickListener {
            selectedFile?.let { uploadAndPredict(it) }
                ?: run { txtResult.text = "Please select an audio file." }
        }

        btnSelectCsv.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "text/*" }
            pickCsv.launch(i)
        }

        btnManualInput.setOnClickListener {
            startActivity(Intent(this, ManualInputActivity::class.java))
        }
    }

    /* ---------------  Helpers  --------------- */

    private fun getFileName(uri: Uri): String =
        contentResolver.query(uri, null, null, null, null)?.use { cur ->
            val idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cur.moveToFirst()) cur.getString(idx) else "file"
        } ?: "file"

    private fun uriToTempFile(uri: Uri): File {
        val tmp = File.createTempFile("upload", ".tmp", cacheDir)
        contentResolver.openInputStream(uri)?.use { it.copyTo(FileOutputStream(tmp)) }
        return tmp
    }

    /* ---- 1) AUDIO → Flask → feature JSON ---- */

    private fun uploadAndPredict(audio: File) {
        val reqBody = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", audio.name, audio.asRequestBody("audio/wav".toMediaTypeOrNull()))
            .build()

        OkHttpClient().newCall(
            Request.Builder()
                .url("http://10.4.73.18:5050/extract")
                .post(reqBody)
                .build()
        ).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { txtResult.text = "Server error: ${e.message}" }
            }

            override fun onResponse(call: Call, resp: Response) {
                val body = resp.body?.string() ?: "{}"
                try {
                    val json = JSONObject(body)
                    val orderedKeys = listOf(
                        "MDVP:Fo(Hz)","MDVP:Fhi(Hz)","MDVP:Flo(Hz)",
                        "MDVP:Jitter(%)","MDVP:Jitter(Abs)","MDVP:RAP",
                        "MDVP:PPQ","Jitter:DDP","MDVP:Shimmer",
                        "MDVP:Shimmer(dB)","Shimmer:APQ3","Shimmer:APQ5",
                        "MDVP:APQ","Shimmer:DDA","NHR","HNR",
                        "RPDE","DFA","spread1","spread2","D2","PPE"
                    )
                    val feat = FloatArray(22) { i -> json.getDouble(orderedKeys[i]).toFloat() }
                    val pred = runOnnxPrediction(feat)
                    runOnUiThread {
                        txtResult.text = if (pred == 1) "Parkinson's Detected" else "Healthy"
                    }
                } catch (ex: Exception) {
                    Log.e("PREDICT", "JSON parse error", ex)
                    runOnUiThread { txtResult.text = "Bad server response." }
                }
            }
        })
    }

    /* ---- 2) CSV ---- */

    private fun parseCsv(uri: Uri): FloatArray? {
        return try {
            contentResolver.openInputStream(uri)?.bufferedReader(StandardCharsets.UTF_8).use { reader ->
                // Skip blank / header lines
                val dataLine = reader?.lineSequence()
                    ?.firstOrNull { it.trim().isNotEmpty() && !it.contains("MDVP") } ?: return null
                val parts = dataLine.split(',', '\t').map { it.trim() }.filter { it.isNotEmpty() }
                if (parts.size != 22) null else FloatArray(22) { i -> parts[i].toFloat() }
            }
        } catch (e: Exception) {
            Log.e("CSV", "Parse error", e); null
        }
    }

    /* ---- 3) ONNX inference ---- */

    private fun runOnnxPrediction(feat: FloatArray): Int {
        val tensor = OnnxTensor.createTensor(
            ortEnv,
            FloatBuffer.wrap(feat),
            longArrayOf(1, feat.size.toLong())
        )
        ortSession.run(mapOf(ortSession.inputNames.iterator().next() to tensor)).use { res ->
            val v = res[0].value
            Log.d("ONNX", "Raw output class-0: $v")

            /** 3a. Preferred: label tensor (int64 / int32) **/
            when (v) {
                is LongArray -> return v[0].toInt()
                is IntArray  -> return v[0]
            }

            /** 3b. Fallback: margin / probability float **/
            val margin: Float? = when (v) {
                is FloatArray        -> v.getOrNull(0)
                is Array<*>          -> (v[0] as? FloatArray)?.getOrNull(0)
                is DoubleArray       -> v.getOrNull(0)?.toFloat()
                else                 -> null
            }

            return if (margin != null) {
                if (margin >= 0f) 1 else 0          // linear-SVM decision function
            } else {
                Log.e("ONNX", "Unknown output type: ${v::class.java}"); 0
            }
        }
    }
}
