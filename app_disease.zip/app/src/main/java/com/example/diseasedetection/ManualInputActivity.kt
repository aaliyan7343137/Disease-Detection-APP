package com.example.diseasedetection

import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import ai.onnxruntime.*

class ManualInputActivity : AppCompatActivity() {

    private lateinit var ortEnv: OrtEnvironment
    private var ortSession: OrtSession? = null
    private lateinit var resultText: TextView
    private lateinit var container: LinearLayout

    /** 22 feature labels in EXACT model order */
    private val featureLabels = listOf(
        "MDVP:Fo(Hz)", "MDVP:Fhi(Hz)", "MDVP:Flo(Hz)",
        "MDVP:Jitter(%)", "MDVP:Jitter(Abs)", "MDVP:RAP",
        "MDVP:PPQ", "Jitter:DDP", "MDVP:Shimmer",
        "MDVP:Shimmer(dB)", "Shimmer:APQ3", "Shimmer:APQ5",
        "MDVP:APQ", "Shimmer:DDA", "NHR", "HNR",
        "RPDE", "DFA", "spread1", "spread2", "D2", "PPE"
    )

    private val inputFields = mutableListOf<EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ── 1.  Load ONNX model ───────────────────────────────────────────────
        ortEnv = OrtEnvironment.getEnvironment()
        val modelBytes = assets.open("svm_parkinsons_model.onnx").readBytes()
        ortSession = ortEnv.createSession(modelBytes)

        // ── 2.  Build a simple scrollable form ────────────────────────────────
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(32, 32, 32, 32)
        }
        setContentView(ScrollView(this).apply { addView(container) })

        // 22 labels + inputs
        featureLabels.forEach { label ->
            container.addView(TextView(this).apply { text = label })
            val edit = EditText(this).apply {
                inputType =
                    InputType.TYPE_CLASS_NUMBER or
                            InputType.TYPE_NUMBER_FLAG_DECIMAL or
                            InputType.TYPE_NUMBER_FLAG_SIGNED     // ← allows negatives
                hint = "Enter $label"
            }
            inputFields += edit
            container.addView(edit)
        }

        // Predict button
        val predictBtn = Button(this).apply {
            text = "Predict"
            setBackgroundColor(0xFF1976D2.toInt())
            setTextColor(0xFFFFFFFF.toInt())
        }
        container.addView(predictBtn)

        // Result area
        resultText = TextView(this).apply {
            text = "Prediction result will appear here"
            textSize = 16f
            setPadding(0, 24, 0, 0)
        }
        container.addView(resultText)

        // Button click → gather numbers → run model
        predictBtn.setOnClickListener {
            try {
                val features = FloatArray(featureLabels.size) { i ->
                    inputFields[i].text.toString().trim().toFloat()
                }
                val rawScore = runOnnxPrediction(features)   // + logging inside
                val verdict  = if (rawScore > 0) "Parkinson's Detected" else "Healthy"
                resultText.text = "$verdict\nRaw score = %.4f".format(rawScore)
            } catch (e: Exception) {
                resultText.text = "Invalid input — please enter all 22 numbers."
                Log.e("ManualInput", "Parse error", e)
            }
        }
    }

    /** Runs the ONNX model and returns the raw decision-function value. */
    private fun runOnnxPrediction(features: FloatArray): Float {
        // — log input
        Log.d("ONNX_IO", "INPUT  ➜ ${features.contentToString()}")

        val tensor = OnnxTensor.createTensor(
            ortEnv,
            java.nio.FloatBuffer.wrap(features),
            longArrayOf(1, features.size.toLong())
        )
        val inputName = ortSession!!.inputNames.first()
        val output    = ortSession!!.run(mapOf(inputName to tensor))[0].value

        val score: Float = when (output) {
            is FloatArray -> output[0]
            is Array<*>   -> (output[0] as FloatArray)[0]
            else          -> 0f
        }

        // — log output
        Log.d("ONNX_IO", "OUTPUT ➜ $score")
        return score
    }
}
